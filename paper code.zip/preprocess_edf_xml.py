# -*- coding: utf-8 -*-
"""
Created on Wed Jan  6 09:38:00 2021

This function is used to preprocess OSA data from Nanfang Hospital. signals used in this research:
    (1) for sleep staging: EEG (C4-A1) and two EOG (left and right) channels;
    (2) for abnormal respiratory detection: Tflow, Pflow, and EEG;
    (3) for arousal: the same channel as sleep staging task.
    

Parameters in this function denote:
(1) base_dir: the directory of data and label.
(2) channel: EEG channel used to score sleep.
(3) d_len: styles of input data length.
(4) cla: classification categories.


@author: LI Fanfan, 3rd Ph.D in School of Biomedical Engineering of Dalian University of Technology.
"""
#%%
import os
import pickle
import glob
import read_edf_xml
import numpy as np

#%%
def prepare_dataset(base_dir):

    #read and preprocessed data
    #edf_path = input('Please input the file name of edfdata: ')
    data_dir = os.path.join(base_dir,'All Data')
    xml_files = glob.glob(os.path.join(data_dir,'*.edf.XML'))
    rml_files = glob.glob(os.path.join(data_dir,'*.rml'))
    hyp_files = xml_files + rml_files
    print('number of records:', len(hyp_files))
     
    #loop on records
    for file in hyp_files:
        Bool = file.endswith('.XML')
        if Bool == True:            
            subject_name = os.path.basename(file)[:-8]
        else:
            subject_name = os.path.basename(file)[:-4]
        edf_name = os.path.join(data_dir,subject_name+'.edf')
        save_file = os.path.join(base_dir,'OSA preprocessed',subject_name+'.p')
        # save_Res_file = os.path.join(base_dir,'OSA preprocessed','Normalized Res task',subject_name+'.p')
        if not os.path.exists(save_file):
            try:              
                print('#####################')
                print('loading data and annotations of {}'.format(subject_name))               
                new_SS_samples,new_Res_samples,new_SS,new_Res = read_edf_xml.read_edf_and_annot(edf_name,file)
                #verify that there is no other stage
                SS_lab,SS_counts = np.unique(new_SS,return_counts=True)
                print('labels and counts for Sleep Staging task:'),
                print(SS_lab,SS_counts)
                
                Res_lab,Res_counts = np.unique(new_Res,return_counts=True)
                print('labels and counts for Respiratory task:'),
                print(Res_lab,Res_counts)

                assert len(new_SS_samples)==len(new_Res_samples)==len(new_SS)==len(new_Res),'the length must be equal'                 
                                

                data = new_SS_samples,new_Res_samples,new_SS,new_Res
                print('saving...')
                    
                if not os.path.exists(os.path.dirname(save_file)):
                    os.makedirs(os.path.dirname(save_file))
                with open(save_file,'wb') as fp:
                    pickle.dump(data,fp)
                
                # if not os.path.exists(os.path.dirname(save_Res_file)):
                #     os.makedirs(os.path.dirname(save_Res_file))
                # with open(save_Res_file,'wb') as fp:
                #     pickle.dump(Res_data,fp)

 
            except FileNotFoundError:
                print('File not found.')
            except AssertionError:
                print('AssertionError. File {} has different length of data and label'.format(subject_name))
                print('Skipping this patient')
                    
            finally:
                pass