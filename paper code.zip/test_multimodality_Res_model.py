# -*- coding: utf-8 -*-
"""
Created on Fri Mar 11 16:36:28 2022

@author: Lifanfan
"""

import os
import glob
import pickle
import numpy as np
import keras
from sklearn import metrics
import matplotlib.pyplot as plt
from pyriemann.utils.viz import plot_confusion_matrix
import math
from sklearn.preprocessing import normalize
os.environ['CUDA_VISIBLE_DEVICES'] = "0"

seed=np.random.seed(2018)

#%%
def cal_res_metrics(y_test,y_pre,results_path,file,sub,cla):
    
    if cla==3:        
        test_lab, _ = np.unique(y_test,return_counts=True)
        pre_lab, _ = np.unique(y_pre,return_counts=True)
        test_lab = list(test_lab) 
        pre_lab = [int(i) for i in pre_lab]
        temp = list(set(pre_lab).union(set(test_lab)))
        if temp == [0,1,2]:
            names = ['Nor','Hyp','Apn']       
        if temp == [0,1]:
            names = ['Nor','Hyp']
        if temp == [0,2]:
            names = ['Nor','Apn']
                 
        # print(names)
        plt.figure()
        plot_confusion_matrix(y_test,y_pre,target_names=names)
        plt.savefig(os.path.join(results_path, '{} Res CM {}.png'.format(file,sub)),dpi=300)
           
        acc_score = metrics.accuracy_score(y_test, y_pre)#acc
        
        # if len(names)==3:
            
        f1_score = metrics.f1_score(y_test, y_pre,average='weighted')#f1
        # else:
        #     f1_score = metrics.f1_score(y_test, y_pre,pos_label=2)#,average='macro')#f1
        
        k_score = metrics.cohen_kappa_score(y_test, y_pre)#k
        #cm
        cm = metrics.confusion_matrix(y_test,y_pre)
        cm_nor = 100 * cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        if names == ['Nor','Hyp']:
            Nor_acc = cm_nor[0,0]
            Hyp_acc = cm_nor[1,1]
            Apn_acc = 'None'
        elif names == ['Nor','Apn']:
            Nor_acc = cm_nor[0,0]
            Hyp_acc = 'None'
            Apn_acc = cm_nor[1,1]
        else: 
            Nor_acc = cm_nor[0,0]
            Hyp_acc = cm_nor[1,1]
            Apn_acc = cm_nor[2,2]
    
    if cla==2:
        names = ['Nor','Abnor']
        plt.figure()
        plot_confusion_matrix(y_test,y_pre,target_names=names)
        plt.savefig(os.path.join(results_path, '{}-res-CM-{}.png'.format(file,sub)),dpi=300)           
        acc_score = metrics.accuracy_score(y_test, y_pre)#acc
        f1_score = metrics.f1_score(y_test, y_pre)
        k_score = metrics.cohen_kappa_score(y_test, y_pre)
        se = metrics.precision_recall_fscore_support(y_test, y_pre)
        cm = metrics.confusion_matrix(y_test,y_pre)
        se = float(format(cm[0,0]/(cm[0,0]+cm[1,0]),'.3f')) #performance for positive
        sp = float(format(cm[1,1]/(cm[0,1]+cm[1,1]),'.3f')) #performance for negative
        
        
    return acc_score, f1_score, k_score, se,sp#, Hyp_acc, Apn_acc
#%%data path
dir_path = 'H:\\check-OSA'
results_path = os.path.join(dir_path,'Results','ECG-AIR 2 cla Res task EEGNETSA')
model_path = os.path.join(results_path,'weight model')
model_files = glob.glob(os.path.join(model_path,'*.h5'))

test_path = os.path.join(dir_path,'EEG-ECG-AIR cv processing')
    
cm_path = os.path.join(results_path,'CM')
if not os.path.exists(cm_path):
    os.makedirs(cm_path)
    
#%%
all_acc = []
all_k = []
all_f1 = []

SE = []
SP = []

nor_num = []
abnor_num = []

for i in range(len(model_files)):
    model_file = model_files[i]
    file = os.path.basename(model_file)[:-3]
    test_model = keras.models.load_model(model_file)
    test_cv_path = os.path.join(test_path,file,'test')
    test_samples = glob.glob(os.path.join(test_cv_path,'*.p'))
      
    for j in test_samples:
        file_name = os.path.basename(j)
        #opening res data
        with open(j,'rb') as f:
            temp_data = pickle.load(f)
        #opening ss daat
        temp_res_sample = temp_data[1]
        temp_ss_sample = np.expand_dims(temp_data[0][:,3,:],axis=1)
        # temp_ss_sample = ss_data[0][:,[0,3],:]

        test_sample = np.concatenate((temp_ss_sample,temp_res_sample),axis=1)
        for m in range(len(test_sample)):
            test_sample[m] = normalize(test_sample[m],axis=1,norm='max')
        test_res_labels = np.array(temp_data[3])
        test_sample = np.expand_dims(test_sample,axis=3)
        Apn_ind = np.where(test_res_labels==2)[0]
        test_res_labels[Apn_ind] = 1   
        nor_ind = np.where(test_res_labels==0)[0]
        abnor_ind = np.where(test_res_labels==1)[0]
        nor_num += len(nor_ind)
        abnor_num += len(abnor_ind)
        y_pre_pro = test_model.predict(test_sample)
        y_pre = np.argmax(y_pre_pro,axis=1)
        
        res_acc, res_f1, res_k,se,sp = cal_res_metrics(test_res_labels,y_pre,cm_path,file,file_name[:-2],cla=2)
        all_acc.append(res_acc)
        all_k.append(res_k)
        all_f1.append(res_f1)
        SE.append(se)
        # All_H.append(Hyp_acc)
        SP.append(sp)
                       
#%%metrics
print('The number of normal breathing:',nor_num)
print('The number of abnormal breathing:',abnor_num)
cv_Res_acc = np.reshape(np.array(all_acc),(5,-1))
cv_Res_f1 = np.reshape(np.array(all_f1),(5,-1))
cv_Res_k = np.reshape(np.array(all_k),(5,-1))

mean_Res_cv_acc = np.mean(cv_Res_acc,axis=1)
mean_Res_cv_f1 = np.mean(cv_Res_f1,axis=1)               
mean_Res_cv_k = np.mean(cv_Res_k,axis=1)  

mean_Res_acc = np.mean(all_acc)
mean_Res_f1 = np.mean(all_f1)   
mean_Res_k = np.mean(all_k)

print('Mean Res accuracy:',mean_Res_acc)
print('Mean Res f1:',mean_Res_f1)
print('Mean Res k:',mean_Res_k)

np.save(os.path.join(model_path,'All_Res_acc'),cv_Res_acc)
np.save(os.path.join(model_path,'All_Res_f1'),cv_Res_f1)
np.save(os.path.join(model_path,'All_Res_k'),cv_Res_k)

#SAVE Normal
# All_sub_N = np.array(All_N).reshape((5,-1))
cv_se = np.reshape(np.array(SE),(5,-1))
cv_sp = np.reshape(np.array(SP),(5,-1))
np.save(os.path.join(model_path,'Al_sub_N'),cv_se)
np.save(os.path.join(model_path,'All_sub_A'),cv_sp)
mean_Res_cv_se = np.mean(cv_se,axis=1)
mean_Res_cv_sp = np.mean(cv_sp,axis=1) 

mean_se_acc = np.mean(SE)
# mean_H_acc = np.mean([x for x in All_H if math.isnan(x)==False])   
mean_sp_acc = np.mean(SP) 
print('Mean se accuracy:',mean_se_acc)
# print('Mean Hyp accuracy:',mean_H_acc)
print('Mean sp accuracy:',mean_sp_acc)