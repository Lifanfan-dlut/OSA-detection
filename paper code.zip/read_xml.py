# -*- coding: utf-8 -*-
"""
Created on Wed Jan  6 09:37:07 2021

This code is used to read stage annotations from XML or RML files.

@author: LI Fanfan, 3rd Ph.D in School of Biomedical Engineering of Dalian University of Technology.
"""

import re
import numpy as np
import xml.dom.minidom as xmldom
import math
#%% Read XML label
def read_XML(xml_file):
#    print(filename)
    with open(xml_file,'r') as f:
        content = f.read()
#        patterns_start = re.findall(r'<EventConcept>Recording Start Time</EventConcept>\n<Start>0</Start>',
#                                    content)
#        assert len(patterns_start) == 1
    patterns_ss = re.findall(r'<SleepStage>.+</SleepStage>',content)
    pat_stages = patterns_ss[0]        
    stages = list(pat_stages[12::26])
    stages = np.array([int(label) for label in stages])
    print('Numbers of Stages:',len(stages))   
    abnormal_ind = np.where(stages==9)
    stages[abnormal_ind] = 0
    #Extract respiratory events:Normal-0, Hypopnea-1, Apnea-2, arousal-1
    Res = []
    Res_starts = []
    Res_durs = []
    Res_ends = []
    
    patterns_res = re.findall(r'<ScoredEvent>'+
                              r'<Name>.+</Name>'+
                              r'<Start>.+</Start>'+
                              r'<Duration>.+</Duration>'+
                              r'<Input>.+</Input>'+
                              r'</ScoredEvent>',content)
    pat_split = patterns_res[0].split('<ScoredEvent>')[1:]
    for event in pat_split:
        if 'Hypopnea' in event:
            temp_plit = event.split('<')[1:]           
            Res.append(1)
            Res_start = float(temp_plit[2][6:])
            Res_starts.append(Res_start)
            Res_dur = float(temp_plit[4][9:])
            Res_durs.append(Res_dur)
            Res_end = int(Res_start+Res_dur)
            Res_ends.append(Res_end)
        if 'Apnea' in event:
            temp_plit = event.split('<')[1:]           
            Res.append(2)
            Res_start = float(temp_plit[2][6:])
            Res_starts.append(Res_start)
            Res_dur = float(temp_plit[4][9:])
            Res_durs.append(Res_dur)
            Res_end = math.ceil(Res_start+Res_dur)
            Res_ends.append(Res_end)
        
        # if 'Arousal' in event:
        #     temp_plit = event.split('<')[1:]           
        #     Arousal.append(2)
        #     Aro_start = int(float(temp_plit[2][6:]))
        #     Aro_starts.append(Aro_start)
        #     Aro_dur = int(float(temp_plit[4][9:]))
        #     Aro_durs.append(Aro_dur)
        #     Aro_end = Aro_start+Aro_dur
        #     Aro_ends.append(Aro_end)

    return stages,Res,Res_starts,Res_ends#,Arousal,Aro_starts,Aro_ends
    
#%% Read RML label
def read_rml(rml_file):
    par_rml = xmldom.parse(rml_file)
    eles = par_rml.documentElement
    Extract_stages = eles.getElementsByTagName('Stage')
    stages = []
    starts = []
    for i in range(len(Extract_stages)):
        stage = Extract_stages[i].getAttribute('Type')
        if stage == 'Wake':
            stages.append(0)
        if stage == 'NonREM1':
            stages.append(1)
        if stage == 'NonREM2':
            stages.append(2)
        if stage == 'NonREM3':
            stages.append(3)
        if stage == 'REM':
            stages.append(5)   
        start = Extract_stages[i].getAttribute('Start')
        starts.append(start)
    starts = [int(start) for start in starts]
    labels = []
    for j in range(len(starts)-1):
        if starts[j+1]-starts[j] != 30:
            labels += [stages[j]]*((starts[j+1]-starts[j])//30)
        if starts[j+1]-starts[j] == 30:
            labels.append(stages[j])
    print('Numbers of Stages:',len(labels))
    labels = np.array(labels)
    #Extract respiratory and Arousal events: Normal-0, Hypopnea-1, Apnea-2, arousal-1
    Res_root = eles.getElementsByTagName('Event')
    # Arousal = []
    # Aro_starts = []
    # Aro_durs = []
    # Aro_ends = []
    Res = []
    Res_starts = []
    Res_durs = []
    Res_ends = []
    for k in range(len(Res_root)):
        Res_type = Res_root[k].getAttribute('Type')
        # if Res_type == 'Arousal':
        #     Arousal.append(1)
        #     Aro_start = Res_root[k].getAttribute('Start')
        #     Aro_starts.append(Aro_start)
        #     Aro_dur = Res_root[k].getAttribute('Duration')
        #     Aro_durs.append(Aro_dur)
        #     Aro_end = Aro_start+Aro_dur
        #     Aro_ends.append(Aro_end)
        if Res_type == 'Hypopnea':
            Res.append(1)
            Res_start = float(Res_root[k].getAttribute('Start'))
            Res_starts.append(Res_start)
            Res_dur = float(Res_root[k].getAttribute('Duration'))
            Res_durs.append(Res_dur)
            Res_end = math.ceil(Res_start+Res_dur)
            Res_ends.append(Res_end)
        if Res_type == 'ObstructiveApnea':
            Res.append(2)
            Res_start = float(Res_root[k].getAttribute('Start'))
            Res_starts.append(Res_start)
            Res_dur = float(Res_root[k].getAttribute('Duration'))
            Res_durs.append(Res_dur)
            Res_end = math.ceil(Res_start+Res_dur)
            Res_ends.append(Res_end)
        if Res_type == 'MixedApnea':
            Res.append(2)
            Res_start = float(Res_root[k].getAttribute('Start'))
            Res_starts.append(Res_start)
            Res_dur = float(Res_root[k].getAttribute('Duration'))
            Res_durs.append(Res_dur)
            Res_end = math.ceil(Res_start+Res_dur)
            Res_ends.append(Res_end)
        if Res_type == 'CentralApnea':
            Res.append(2)
            Res_start = float(Res_root[k].getAttribute('Start'))
            Res_starts.append(Res_start)
            Res_dur = float(Res_root[k].getAttribute('Duration'))
            Res_durs.append(Res_dur)
            Res_end = math.ceil(Res_start+Res_dur)
            Res_ends.append(Res_end)

    return labels,Res,Res_starts,Res_ends#,Arousal,Aro_starts,Aro_ends
        
        
        
    
    