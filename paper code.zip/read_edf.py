# -*- coding: utf-8 -*-
"""
Created on Wed Jan  6 09:35:22 2021

This code is used to extract EEG,EOG, ECG, respiratory signals from PSG files.

@author: LI Fanfan, 3rd Ph.D in School of Biomedical Engineering of Dalian University of Technology. 
"""

import pyedflib
import numpy as np
from scipy.interpolate import interp1d
from sklearn.preprocessing import normalize

#%% 
def changing_fs(raw_signal,raw_sr,new_sr):
    
    new_signal_len = int((len(raw_signal)//raw_sr)*new_sr)
    x = np.arange(len(raw_signal))
    # y = raw_signal
    x_new = np.linspace(0,len(raw_signal)-1,new_signal_len)
    f = interp1d(x, raw_signal, kind='cubic')
    new_signal = f(x_new)
    
    return new_signal

#%%
def read_edfrecord(edffile): #the value of length is only related to respiratory signals

    EEG_channels = ['C4-M1','EEG C4-A1']
    EOG_channels = ['E1-M2','E2-M2','EOG LOC-A2','EOG ROC-A2','EOG ROC-A1']
    air_channels = ['Nasal Pressure','Flow Patient','Airflow','Pres Patient','Therm','Therm Patient']
    ECG_channels = ['RIP ECG','ECG II','ECG I','ECG1-ECG2']
    f = pyedflib.EdfReader(edffile)
    # signal_duration =f.getFileDuration()
    signal_labels = f.getSignalLabels()
    SS_channels = []
    #EEG channel  
    eeg_chan = list(set(EEG_channels)&set(signal_labels))
    SS_channels+=eeg_chan
    #EOG channel  
    eog_chan = list(set(EOG_channels)&set(signal_labels))
    SS_channels+=eog_chan
    #ECG channel  
    ecg_chan = list(set(ECG_channels)&set(signal_labels))
    if len(ecg_chan)==2:
        ecg_chan = ['ECG II']
    else:
        ecg_chan = ecg_chan
    SS_channels+=ecg_chan            
   
    #extracting SLeep staging signals
    i = 0
    SS_sig = [None]*4
    new_sr = 200           
    for chan in SS_channels:
        SS_chan_index = signal_labels.index(chan)            
        SS_sig[i] = f.readSignal(SS_chan_index)
        SS_channel_sf = f.getSampleFrequency(SS_chan_index)
        if SS_channel_sf != new_sr:
            SS_sig[i] = changing_fs(SS_sig[i],SS_channel_sf,new_sr)
        i += 1
    #extracting Airflow signals
    #AIR channel
    Res_chan = list(set(air_channels)&set(signal_labels))
    Res_sig = [None]*2
    if len(Res_chan)==1:        
        Res_chan_index = signal_labels.index(Res_chan[0])
        Res_channel_sf = f.getSampleFrequency(Res_chan_index)
        
        Res_sig[0] = f.readSignal(Res_chan_index+1)#Nasal pressure
        Res_sig[1] = f.readSignal(Res_chan_index)#Therm
        
        if Res_channel_sf != new_sr:
            Res_sig[0] = changing_fs(Res_sig[0],Res_channel_sf,new_sr)
            Res_sig[1] = changing_fs(Res_sig[1],Res_channel_sf,new_sr)
        else:
            Res_sig[0] = Res_sig[0]
            Res_sig[1] = Res_sig[1]
    if len(Res_chan)==2:
        if signal_labels.count('Nasal Pressure')==2:
            NP_chan_index = signal_labels.index('Nasal Pressure')
            NP_channel_sf = f.getSampleFrequency(NP_chan_index+1)
            TH_channel_sf = f.getSampleFrequency(NP_chan_index+2)
            Res_sig[0] = f.readSignal(NP_chan_index+1)
            Res_sig[1] = f.readSignal(NP_chan_index+2)
            if NP_channel_sf != new_sr:
                Res_sig[0] = changing_fs(Res_sig[0],NP_channel_sf,new_sr)
                Res_sig[1] = changing_fs(Res_sig[1],TH_channel_sf,new_sr)
            
        elif signal_labels.count('Nasal Pressure')==1:
            NP_chan_index = signal_labels.index('Nasal Pressure')
            NP_channel_sf = f.getSampleFrequency(NP_chan_index)
            TH_channel_sf = f.getSampleFrequency(NP_chan_index+1)
            Res_sig[0] = f.readSignal(NP_chan_index)
            Res_sig[1] = f.readSignal(NP_chan_index+1)
            if NP_channel_sf != new_sr:
                Res_sig[0] = changing_fs(Res_sig[0],NP_channel_sf,new_sr)
                Res_sig[1] = changing_fs(Res_sig[1],TH_channel_sf,new_sr)
        else:
            
            NP_chan_index = signal_labels.index(Res_chan[0])
            TH_chan_index = signal_labels.index(Res_chan[1])
            NP_channel_sf = f.getSampleFrequency(NP_chan_index)
            TH_channel_sf = f.getSampleFrequency(TH_chan_index)
            NP_channel_sf = f.getSampleFrequency(NP_chan_index)
            TH_channel_sf = f.getSampleFrequency(TH_chan_index)
            Res_sig[0] = f.readSignal(NP_chan_index)#Nasal pressure
            Res_sig[1] = f.readSignal(TH_chan_index)#Therm
            if NP_channel_sf != new_sr:
                Res_sig[0] = changing_fs(Res_sig[0],NP_channel_sf,new_sr)
                Res_sig[1] = changing_fs(Res_sig[1],TH_channel_sf,new_sr)
            
    SS_sig = np.array(SS_sig)         
    Res_sig = np.array(Res_sig)
    
    #spliting signals
    #time_win = 60
    epoch_len = new_sr*30
    num_epochs = SS_sig.shape[1]//epoch_len
    SS_sig_eff,Res_sig_eff = SS_sig[:,:int(num_epochs*epoch_len)],Res_sig[:,:int(num_epochs*epoch_len)]
    #normalizing the whole signal
    
    # SS_sig_eff = normalize(SS_sig_eff,axis=1,norm='max')
    # Res_sig_eff = normalize(Res_sig_eff,axis=1,norm='max')
    SS_samples = np.array(np.split(SS_sig_eff,num_epochs,axis=1))
    Res_samples = np.array(np.split(Res_sig_eff,num_epochs,axis=1))           
        
    # nor_multi_epochs = scale(multi_epochs,axis=1)
    
    return SS_samples, Res_samples
