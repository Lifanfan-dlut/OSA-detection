# -*- coding: utf-8 -*-
"""
Created on Thu May 20 18:41:21 2021

@author: LI Fanfan, 3rd Ph.D in School of Biomedical Engineering of Dalian University of Technology.
"""

import read_edf
from read_xml import read_XML, read_rml
import numpy as np

#%%
def read_edf_and_annot(edf_file,hyp_file):
    
    SS_samples, Res_samples = read_edf.read_edfrecord(edf_file)
    hyp_bool = hyp_file.endswith('.XML')
    if hyp_bool==True:
        stages,Res,Res_starts,Res_ends = read_XML(hyp_file)
        stages = stages.reshape((-1,1))
    else:
        stages,Res,Res_starts,Res_ends = read_rml(hyp_file)
        stages = stages.reshape((-1,1))
    
    #creating 1min length samples
    new_SS_samples = []
    new_Res_samples = []
    new_SS = []
    new_Res = []
    for idx in range(len(stages)-1):                                                                
        SS_sample_before = SS_samples[idx]
        SS_sample_after = SS_samples[idx+1]
        SS_joint_sample = np.concatenate((SS_sample_before,SS_sample_after),axis=1)
        new_SS_samples.append(SS_joint_sample)
        
        Res_sample_before = Res_samples[idx]
        Res_sample_after = Res_samples[idx+1]
        Res_joint_sample = np.concatenate((Res_sample_before,Res_sample_after),axis=1)
        new_Res_samples.append(Res_joint_sample)
        
        #creating SS labels
        SS_label_before = stages[idx]
        SS_label_after = stages[idx+1]
        if SS_label_before==SS_label_after:
            new_SS.append(SS_label_before)
        else:
            if SS_label_before>SS_label_after:
                new_SS.append(SS_label_before)
            if SS_label_before<SS_label_after:
                new_SS.append(SS_label_after)
        
        #creating Res labels
        epoch_start = idx*30
        epoch_end = (idx+2)*30
        temp_Res_lab = []
        for i in range(len(Res)):
            event_start = Res_starts[i]
            event_end = Res_ends[i]
            if epoch_end>event_start>epoch_start and epoch_end-event_start>=10:
                temp_Res_lab.append(Res[i])
            elif event_end>epoch_start>event_start and event_end-epoch_start>=10:
                temp_Res_lab.append(Res[i])
            elif event_end>epoch_end>epoch_start>event_start:
                temp_Res_lab.append(Res[i])
            
            else:
                temp_Res_lab.append(0)
        
        if 2 in temp_Res_lab:
            new_Res.append(2)
        else:
            if 1 in temp_Res_lab:
              new_Res.append(1)
            else:
                new_Res.append(0)
                
    
    new_SS_samples = np.array(new_SS_samples)
    new_Res_samples = np.array(new_Res_samples)
    new_SS = np.array(new_SS)
    new_Res = np.array(new_Res)
    
    #Trimming the extra 5minutes wake stages at the beginning of the sleep
    first_nonzero_ind = np.nonzero(new_SS)[0][0]
    if first_nonzero_ind > 10:
        print('Trimming......')
        new_SS_samples = new_SS_samples[first_nonzero_ind-10:,:,:]
        new_Res_samples = new_Res_samples[first_nonzero_ind-10:,:,:]
        new_SS = new_SS[first_nonzero_ind-10:]
        new_Res = new_Res[first_nonzero_ind-10:]
    #keeping the last 3minutes wake sages.
    last_nonzero_ind = np.nonzero(new_SS)[0][-1]
    if (len(new_SS)-last_nonzero_ind-1)>6:
        print('Trimming......')
        new_SS_samples = new_SS_samples[:(last_nonzero_ind+7),:,:]
        new_Res_samples = new_Res_samples[:(last_nonzero_ind+7),:,:]
        new_SS = new_SS[:(last_nonzero_ind+7)]
        new_Res = new_Res[:(last_nonzero_ind+7)]
    
    return new_SS_samples,new_Res_samples,new_SS,new_Res