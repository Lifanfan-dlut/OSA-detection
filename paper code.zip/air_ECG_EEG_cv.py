# -*- coding: utf-8 -*-
"""
Created on Fri Mar 11 08:41:00 2022

@author: Lifanfan
"""

import os
import glob
import pickle
import numpy as np
# from sklearn.preprocessing import scale
# import shutil
#%%loading data

dir_path = 'H:\\check-OSA' 
data_path = os.path.join(dir_path,'OSA preprocessed')
data_files = glob.glob(os.path.join(data_path,'*.p'))
saving_path =  os.path.join(dir_path,'EEG-ECG-AIR cv processing')
if not os.path.exists(saving_path):
    os.makedirs(saving_path) 

#%%Loading data and saving each CV train data
splits = 5

for i in range(splits):
    print('The {}th cross validation###########'.format(i+1))
        
    saving_cv_path = os.path.join(saving_path,'cv{}'.format(i+1))
    if not os.path.exists(saving_cv_path):
        os.makedirs(saving_cv_path)
    saving_test_cv_path = os.path.join(saving_cv_path,'test')
    test_files = glob.glob(os.path.join(saving_test_cv_path,'*.p'))
    temp_test_files = []
    for test_file in test_files:
        test_name = os.path.basename(test_file)
        test_file_path = os.path.join(data_path,test_name)
        temp_test_files.append(test_file_path)
        
    train_files = [file for file in data_files if file not in temp_test_files]
    # if not os.path.exists(saving_test_cv_path):
    #     os.makedirs(saving_test_cv_path)
    # for test_file in test_files:
    #     shutil.copy(test_file, saving_test_cv_path)
    train_samples = []#['nasal pressure', 'Therm']
    # train_samples = np.zeros((0,8,sample_len))
    train_res_labels = []
    for j in train_files:
        file_name = os.path.basename(j)
        # file = os.path.join(data_path,file_name)
        #opening res data
        with open(j,'rb') as f:
            temp_data = pickle.load(f)
        
        temp_res_sample = temp_data[1]
        temp_ss_sample = temp_data[0][:,[0,3],:]
        
        temp_sample = np.concatenate((temp_res_sample,temp_ss_sample),axis=1)
        train_samples.append(temp_sample)
        train_res_labels.append(temp_data[3])

    train_samples = np.concatenate(train_samples)
    train_res_labels = np.concatenate(train_res_labels)
    assert len(train_samples)==len(train_res_labels) ,'they must be equal'
        
    # res_lab, lab_count = np.unique(train_res_labels,return_counts=True)
    # print(res_lab, lab_count)
    # train_samples = np.expand_dims(train_samples,axis=3)
      
    data_train = train_samples,train_res_labels
    print('saving train data...')
    save_train_file = os.path.join(saving_cv_path,'train','train data.p')
    if not os.path.exists(os.path.dirname(save_train_file)):
        os.makedirs(os.path.dirname(save_train_file))
    with open(save_train_file,'wb') as fp:
        pickle.dump(data_train,fp,protocol=4)
        
