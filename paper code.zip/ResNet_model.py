# -*- coding: utf-8 -*-
"""
Created on Mon Mar 28 22:15:23 2022

@author: LI Fanfan, 3rd Ph.D in School of Biomedical Engineering of Dalian University of Technology.
"""
from keras.models import Model
from keras.layers import Conv2D,AveragePooling2D
from keras.layers import SeparableConv2D, DepthwiseConv2D
from keras.layers import Dense,Activation
from keras.layers import BatchNormalization
from keras.layers import Concatenate,Reshape
from keras.constraints import max_norm
from keras.layers import Conv1D,GlobalAveragePooling1D
from keras.layers import Input
import keras.backend as K

#%%
def EEGNET_SA_2D(chan_num,epoch_len,classes):   

    input_shape = Input(shape=(chan_num,epoch_len*200,1))
    #
    x1 = Conv2D(64,(1,100),strides=(1,3),padding='same')(input_shape)
    x1 = BatchNormalization()(x1)
    x1 = Activation('relu')(x1)
    print(x1.shape)
    #
    x2 = Conv2D(64,(1,3),strides=(1,3),padding='same')(input_shape)
    x2 = BatchNormalization()(x2)
    x2 = Activation('relu')(x2)
    print(x2.shape)
    #
    x = Concatenate(axis=3)([x1,x2])
    print(x.shape)
    #2D
   
    x = DepthwiseConv2D((chan_num, 1), use_bias = False, 
                        depth_multiplier = 2,
                        depthwise_constraint = max_norm(1.))(x)
    x = BatchNormalization()(x)
    x = Activation('elu')(x)
    x = AveragePooling2D((1, 4))(x)
    
    x = SeparableConv2D(128, (1, 16),
                        use_bias = False, padding = 'same')(x)
    x = BatchNormalization()(x)
    x = Activation('elu')(x)
    x = AveragePooling2D((1, 8))(x)
    x = Reshape((-1,128))(x)
    Q_w = Conv1D(64,1)(x)
    print(Q_w.shape)
    K_w = Conv1D(64,1)(x)
    print(K_w.shape)
    QK = K.batch_dot(Q_w,K.permute_dimensions(K_w,[0,2,1]))
    QK = QK/(64**0.5)
    QK = K.softmax(QK)
    print('QK.shape',QK.shape)
    V_w = Conv1D(64,1)(x)
    z = K.batch_dot(QK,V_w)
    print('z.shape',z.shape)
    x = GlobalAveragePooling1D()(z) 

    x = Dense(classes)(x)
    model_out = Activation('softmax')(x)
    model = Model(inputs=input_shape,outputs=model_out)
    return model